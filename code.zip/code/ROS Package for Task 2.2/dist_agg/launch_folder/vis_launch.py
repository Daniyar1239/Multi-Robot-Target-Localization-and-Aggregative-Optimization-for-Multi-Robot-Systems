from launch import LaunchDescription
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node
from datetime import datetime
import os, random

package = "dist_agg"

out_dir = "/home/user/docker_ws/src"
csv_path = os.path.join(out_dir, f"metrics.csv")

GRAPH_TOPOLOGY = "star"
STAR_CENTER = 0 # used only for the "star" graph

def sample_points(N, xlim, ylim):
    return [[random.uniform(*xlim), random.uniform(*ylim)] for _ in range(N)]

def build_adjacency(N, kind):
    adj = {i: [] for i in range(N)}
    if kind == "ring":
        for i in range(N):
            adj[i].append((i - 1) % N)
            adj[i].append((i + 1) % N)
    elif kind == "path":
        for i in range(N - 1):
            adj[i].append(i + 1)
            adj[i + 1].append(i)
    elif kind == "star":
        c = STAR_CENTER
        for i in range(N):
            if i == c:
                continue
            adj[c].append(i)
            adj[i].append(c)
    elif kind == "complete":
        for i in range(N):
            for j in range(N):
                if i != j:
                    adj[i].append(j)
    else:
        raise ValueError(f"Unknown topology")
    # Sort for determinism
    for i in range(N):
        adj[i] = sorted(set(adj[i]))
    return adj

def neighbor_degrees_from_adj(adj):
    N = len(adj)
    degrees = [len(adj[i]) for i in range(N)]
    neigh_ids = {}
    neigh_degrees = {}
    for i in range(N):
        ids = adj[i]
        neigh_ids[i] = ids
        neigh_degrees[i] = [degrees[j] for j in ids]
    return neigh_ids, neigh_degrees

def generate_launch_description():
    N = 10 # number of agents
    dt = 0.1
    alpha = 0.05   # step size
    a_track = 1.0   # weight for tracking
    b_tight = 1.0   # weight for tightness

    # Sampling bounds
    init_xlim = (-2.0, 2.0); init_ylim = (-2.0, 2.0)
    targ_xlim = (-2.0, 2.0); targ_ylim = (-2.0, 2.0)

    x_inits = sample_points(N, init_xlim, init_ylim)
    targets = sample_points(N, targ_xlim, targ_ylim)
    targets_flat = [c for xy in targets for c in xy] # for plotting metrics

    # Build the communication graph
    adj = build_adjacency(N, GRAPH_TOPOLOGY)
    neigh_ids, neigh_degs = neighbor_degrees_from_adj(adj)

    ld = []
    
    ####### Agents #######
    for i in range(N):
        ld.append(
            Node(
                package=package,
                executable="generic_agent",
                name=f"agent_{i}",
                parameters=[{
                    "agent_id": i,
                    "x_init": x_inits[i],
                    "target": targets[i],
                    "alpha": alpha,
                    "a_track": a_track,
                    "b_tight": b_tight,
                    "dt": dt,
                    "max_step_norm": 0.0,
                    "neighbor_ids": neigh_ids[i],
                    "neighbor_degrees": neigh_degs[i],
                    "max_iters": 1000,
                }],
                output="screen",
            )
        )
        
    ####### Barycenter #######
    ld.append(
        Node(
            package=package,
            executable="sigma_node",
            name="sigma_node",
            parameters=[{"N": N,
            "dt": dt,
            "require_all": True}],
            output="screen",
        )
    )

    ####### Metrics (cost and gradnorm) #######
    ld.append(
        Node(
            package=package,
            executable="metrics_node",
            name="metrics_node",
            parameters=[{
                "N": N,
                "targets_flat": targets_flat,
                "a_track": a_track,
                "b_tight": b_tight,
                "csv_path": csv_path,
                "dt": dt,
            }],
            output="screen",
        )
    )

    ####### Multi-agent visualizer #######
    ld.append(
        Node(
            package=package,
            executable="generic_visualizer",
            name="multi_visualizer",
            parameters=[{"N": N, "scale": 0.35, "dt": dt}],
            output="screen",
        )
    )
    rviz_share = get_package_share_directory(package)
    rviz_cfg = os.path.join(rviz_share, "rviz_config.rviz")
    ld.append(Node(package="rviz2", executable="rviz2", arguments=["-d", rviz_cfg], output="screen"))

    print(f"[vis_launch1] N={N}, graph='{GRAPH_TOPOLOGY}' -> degrees:",
          {i: len(adj[i]) for i in range(N)})
          
    return LaunchDescription(ld)
