import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from visualization_msgs.msg import Marker, MarkerArray

class MultiVisualizer(Node):
    def __init__(self):
        super().__init__("multi_visualizer")
        self.declare_parameter("N", 3)
        self.declare_parameter("scale", 0.3)
        self.N = int(self.get_parameter("N").value)
        self.scale = float(self.get_parameter("scale").value)
        self.declare_parameter("dt", 0.1)

        self.scale = float(self.get_parameter("scale").value)
        self.dt = float(self.get_parameter("dt").value)

        self.pos = {i: None for i in range(self.N)}
        self.sigma = None
        for i in range(self.N):
            self.create_subscription(Point, f"/agent_{i}/pos", self._mk_cb(i), 10)  # subscribes to agents' positions
        self.create_subscription(Point, "/sigma", self._cb_sigma, 10)  # subscribes to the sigma

        self.pub = self.create_publisher(MarkerArray, "/viz/markers", 10)

        self.timer = self.create_timer(self.dt, self._publish)
        
        self.colors = [
            (1.0, 0.2, 0.2, 1.0), (0.2, 1.0, 0.2, 1.0), (0.2, 0.2, 1.0, 1.0),
            (1.0, 0.6, 0.0, 1.0), (0.6, 0.0, 1.0, 1.0), (0.0, 0.8, 0.8, 1.0),
        ]

    def _mk_cb(self, i):
        def cb(msg: Point):
            self.pos[i] = (msg.x, msg.y)
        return cb

    def _cb_sigma(self, msg: Point):  # stores the latest x,y values of the barycenter
        self.sigma = (msg.x, msg.y)

    def _publish(self):
        arr = MarkerArray()
        for i in range(self.N):  # for each agent (sphere)
            if self.pos[i] is None: continue
            m = Marker()
            m.header.frame_id = "map" 
            m.ns = "agents" 
            m.id = i
            m.type = Marker.SPHERE
            m.action = Marker.ADD
            m.pose.position.x= self.pos[i][0]
            m.pose.position.y = self.pos[i][1]
            m.pose.position.z = 0.0
            m.scale.x = m.scale.y = m.scale.z = self.scale
            r,g,b,a = self.colors[i % len(self.colors)]
            m.color.r, m.color.g, m.color.b, m.color.a = r,g,b,a
            arr.markers.append(m)
        if self.sigma is not None: # for the barycenter (cube)
            m = Marker()
            m.header.frame_id = "map"
            m.ns = "barycenter"
            m.id = 10_000
            m.type = Marker.CUBE
            m.action = Marker.ADD
            m.pose.position.x = self.sigma[0]
            m.pose.position.y = self.sigma[1]
            m.pose.position.z = 0.0
            m.scale.x = m.scale.y = m.scale.z = self.scale * 0.6
            m.color.r, m.color.g, m.color.b, m.color.a = 1.0, 1.0, 0.2, 1.0
            arr.markers.append(m)
        if arr.markers: self.pub.publish(arr)

def main(args=None):
    rclpy.init(args=args)
    node = MultiVisualizer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
