import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from rclpy.parameter import ParameterValue
from rcl_interfaces.msg import ParameterDescriptor, ParameterType
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy

def _pt(xy):
    p = Point()
    p.x, p.y, p.z = float(xy[0]), float(xy[1]), 0.0
    return p

class AggAgent(Node):
    def __init__(self):
    
        super().__init__("agg_agent")

        # Explicit declarations with defaults
        self.declare_parameter("agent_id", 0)
        self.declare_parameter("x_init", [0.0, 0.0])
        self.declare_parameter("target", [1.0, 0.0])
        self.declare_parameter("alpha", 0.1)
        self.declare_parameter("a_track", 1.0)   
        self.declare_parameter("b_tight", 1.0)
        self.declare_parameter("dt", 0.1)
        self.declare_parameter("max_step_norm", 0.2)
        self.declare_parameter("max_iters", 2000)   

        int_array_desc = ParameterDescriptor(type=ParameterType.PARAMETER_INTEGER_ARRAY)
        empty_int_array = ParameterValue(type=ParameterType.PARAMETER_INTEGER_ARRAY, integer_array_value=[])
        self.declare_parameter("neighbor_ids", empty_int_array, descriptor=int_array_desc)
        self.declare_parameter("neighbor_degrees", empty_int_array, descriptor=int_array_desc)

        # Reading the parameters values into Python vars
        self.agent_id = int(self.get_parameter("agent_id").value)
        self.z = np.array(self.get_parameter("x_init").value, dtype=float)
        self.t = np.array(self.get_parameter("target").value, dtype=float)
        self.alpha = float(self.get_parameter("alpha").value)
        self.a = float(self.get_parameter("a_track").value)
        self.b = float(self.get_parameter("b_tight").value)
        self.dt = float(self.get_parameter("dt").value)
        self.max_step = float(self.get_parameter("max_step_norm").value)
        self.max_iters = int(self.get_parameter("max_iters").value)
        self.neigh_ids = list(self.get_parameter("neighbor_ids").value)
        self.neigh_degrees = list(self.get_parameter("neighbor_degrees").value)

        if len(self.neigh_degrees) != len(self.neigh_ids):
            self.get_logger().warn(
                "neighbor_degrees missing/mismatched; falling back to deg_j = deg_i for MH weights"
            )
            self.neigh_degrees = [len(self.neigh_ids)] * len(self.neigh_ids)

        # QoS (helps with message drops)
        qos = QoSProfile(depth=10)
        qos.reliability = QoSReliabilityPolicy.RELIABLE
        qos.history = QoSHistoryPolicy.KEEP_LAST

        # Initializing the algorithm variables
        self.y = self.z.copy()
        self.s = self._grad(self.z, self.y)

        # Metropolis-Hastings weights
        deg_i = len(self.neigh_ids)
        self.w_ij = {}
        for j, dj in zip(self.neigh_ids, self.neigh_degrees):
            self.w_ij[j] = 1.0 / (1.0 + float(max(deg_i, int(dj))))
        self.w_ii = 1.0 - sum(self.w_ij.values())
         # Sanity check: weights must sum to 1
        total_w = self.w_ii + sum(self.w_ij.values())
        if abs(total_w - 1.0) > 1e-9:
            self.get_logger().error(f"MH weights do not sum to 1 (sum={total_w})")

        self.pos_pub = self.create_publisher(Point, f"/agent_{self.agent_id}/pos", qos) # publishes the agent's position
        self.pub_s = self.create_publisher(Point, f"/agt/agent_{self.agent_id}/s", qos) # gradient 
        self.pub_y = self.create_publisher(Point, f"/agt/agent_{self.agent_id}/y", qos) # tracker

        self.y_nb = {}  
        for j in self.neigh_ids:
            self.create_subscription(Point, f"/agt/agent_{j}/y", self._mk_store(self.y_nb, j), qos) # subscription to neighbors' y

        # Publish initial values so mixing can start immediately
        self._publish_all()

        self.timer = self.create_timer(self.dt, self._step)
        self.k = 0
        
        # Printing a line with key parameters for checking the launch inputs
        self.get_logger().info(
            f"Agent id={self.agent_id} deg={deg_i} alpha={self.alpha} a={self.a} b={self.b} "
            f"neighbors={self.neigh_ids}"
        )

##### Helper functions
    def _mk_store(self, store, key):
        def cb(msg: Point):
            store[key] = np.array([msg.x, msg.y], dtype=float)
        return cb

    def _publish_all(self):
        self.pos_pub.publish(_pt(self.z))
        self.pub_s.publish(_pt(self.s))
        self.pub_y.publish(_pt(self.y))

    def _clip(self, v):
        if self.max_step <= 0.0:
            return v
        n = float(np.linalg.norm(v))
        return v if n <= self.max_step else v * (self.max_step / (n + 1e-12))

    def _mix(self, self_vec, nb_dict):
        acc = self.w_ii * self_vec
        for j in self.neigh_ids:
            vj = nb_dict.get(j, self_vec)
            acc = acc + self.w_ij[j] * vj
        return acc

    def _grad(self, z, y):
        return self.a * (z - self.t) + self.b * (z - y) 

##### Aggregative Gradient Tracking
    def _step(self):
        z_k, y_k = self.z.copy(), self.y.copy()

        # local gradient at current state
        g_k = self._grad(z_k, y_k)

        dz = self._clip(-self.alpha * g_k)
        z_k1 = z_k + dz

        # Dynamic average consensus to track barycenter of z
        y_mix = self._mix(y_k, self.y_nb)
        y_k1 = y_mix + (z_k1 - z_k)

        s_k1 = self._grad(z_k1, y_k1)

        self.z, self.s, self.y = z_k1, s_k1, y_k1

        if (self.k % 20) == 0:
            self.get_logger().info(
                f"id={self.agent_id} | ||step||={np.linalg.norm(dz):.4e} | "
                f"||grad||={np.linalg.norm(g_k):.4e} | ||y||={np.linalg.norm(y_k):.4e}"
            )
        self.k += 1

        if self.k >= self.max_iters:
            self.get_logger().info("Max iterations reached, shutting down agents.")
            self.destroy_node()
            return

        self._publish_all()


def main(args=None):
    rclpy.init(args=args)
    node = AggAgent()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
