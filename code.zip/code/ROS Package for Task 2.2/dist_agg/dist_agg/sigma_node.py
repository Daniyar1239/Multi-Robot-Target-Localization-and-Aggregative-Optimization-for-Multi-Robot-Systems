import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point

class SigmaNode(Node):
    def __init__(self):
        super().__init__("sigma_node")

        self.declare_parameter("N", 3) 
        self.declare_parameter("dt", 0.1)
        self.declare_parameter("require_all", True) 

        self.N = int(self.get_parameter("N").value)
        self.dt = float(self.get_parameter("dt").value)
        self.latest = {i: None for i in range(self.N)} # saves each agent's latest x,y positions
        self.require_all = bool(self.get_parameter("require_all").value)
        
        # Subscriptions
        for i in range(self.N):
            self.create_subscription(Point, f"/agent_{i}/pos", self._mk_cb(i), 10) 
        
        # Publisher of the barycenter
        self.pub = self.create_publisher(Point, "/sigma", 10)

        # Timer
        self.timer = self.create_timer(self.dt, self._tick)
    
    # To avoid late binding pitfalls in loops
    def _mk_cb(self, i):
        def cb(msg: Point): 
            self.latest[i] = (msg.x, msg.y)
        return cb

    def _tick(self):
        vals = list(self.latest.values())
        if self.require_all and any(v is None for v in vals):  # collecting the available data (some agents may have not started yet or dropped messages)
            return
        vals = [v for v in vals if v is not None] 
        if not vals: 
            return
        sx = sum(v[0] for v in vals) / len(vals)  # computing the barycenter wrt x
        sy = sum(v[1] for v in vals) / len(vals)  # computing the barycenter wrt y
        p = Point(); p.x, p.y, p.z = float(sx), float(sy), 0.0
        self.pub.publish(p)

def main(args=None):
    rclpy.init(args=args)
    node = SigmaNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()
