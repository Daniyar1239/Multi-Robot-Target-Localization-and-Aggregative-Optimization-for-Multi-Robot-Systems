import csv
import os
import time
import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from std_msgs.msg import Float32

class MetricsNode(Node):
    def __init__(self):
        super().__init__("metrics_node")
        
        self.declare_parameter("N", 3)
        self.declare_parameter("targets_flat", [0.0])
        self.declare_parameter("a_track", 1.0)  
        self.declare_parameter("b_tight", 1.0) 
        self.declare_parameter("dt", 0.1)
        self.declare_parameter("csv_path", "metrics_task22.csv")

        self.N = int(self.get_parameter("N").value)

        flat = self.get_parameter("targets_flat").value
        arr = np.array(flat, dtype=float).reshape((-1, 2))
        self.targets = arr[: self.N]

        self.a = float(self.get_parameter("a_track").value)
        self.b = float(self.get_parameter("b_tight").value)
        self.dt = float(self.get_parameter("dt").value)
        self.csv_path = str(self.get_parameter("csv_path").value)

        # Subscribers
        self.z = {i: None for i in range(self.N)}
        self.y = {i: None for i in range(self.N)}
        self.sigma = np.zeros(2)
        self.have_sigma = False
        for i in range(self.N):
            self.create_subscription(Point, f"/agent_{i}/pos", self._mk_cb_pos(i), 10)
            self.create_subscription(Point, f"/agt/agent_{i}/y", self._mk_cb_y(i), 10)
        self.create_subscription(Point, "/sigma", self._cb_sigma, 10)

        # Publishers
        self.cost_pub = self.create_publisher(Float32, "/metrics/cost", 10)
        self.grad_pub = self.create_publisher(Float32, "/metrics/grad_norm", 10)

        # CSV
        self._prepare_csv()
        self.k = 0
        self.timer = self.create_timer(self.dt, self._tick)

        self.get_logger().info(
            f"Metrics node: N={self.N}, a={self.a}, b={self.b}, CSV='{os.path.abspath(self.csv_path)}'"
        )

    def _prepare_csv(self):
        header_needed = not os.path.exists(self.csv_path)
        if header_needed:
            with open(self.csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["k", "cost", "grad_norm"])

    def _mk_cb_pos(self, i):
        def cb(msg: Point):
            self.z[i] = np.array([msg.x, msg.y], dtype=float)
        return cb
    
    def _mk_cb_y(self, i):
        def cb(msg: Point):
            self.y[i] = np.array([msg.x, msg.y], dtype=float)
        return cb

    def _cb_sigma(self, msg: Point):
        self.sigma = np.array([msg.x, msg.y], dtype=float)
        self.have_sigma = True

    def _tick(self):
        if not self.have_sigma:
            return
        if any(self.z[i] is None for i in range(self.N)):
            return
        if any(self.y[i] is None for i in range(self.N)):
            return

        Z = np.vstack([self.z[i] for i in range(self.N)])
        Y = np.vstack([self.y[i] for i in range(self.N)]) 
        T = self.targets

        # Cost
        dif1 = Z - T
        dif2 = Z - Y
        term1 = 0.5 * self.a * np.sum(dif1**2)
        term2 = 0.5 * self.b * np.sum(dif2**2)
        cost = float(term1 + term2)

        # Gradient norm
        G = self.a * dif1 + self.b * dif2 + (1 / self.N) * np.sum(self.b * (Z - self.sigma), axis=0)
        #G = self.a * dif1 + self.b * dif2
        grad_norm = float(np.linalg.norm(np.sum(G, axis=0)))

        # Publish
        self.cost_pub.publish(Float32(data=cost))
        self.grad_pub.publish(Float32(data=grad_norm))

        # Save
        with open(self.csv_path, "a", newline="") as f:
            csv.writer(f).writerow([self.k, cost, grad_norm])

        self.k += 1

def main(args=None):
    rclpy.init(args=args)
    node = MetricsNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()

