# Aggregative Optimization for Multi-Robot Systems in ROS 2 (Task 2.2)

## Description:
This is the implementation of Task 2.2 of the project. The package `dist_agg` has been created for visualizing the robots' team behavior in the aggregative optimization scenario and plotting the metrics plots from Task 2.1.

## Package Structure:
dist_agg/
├── dist_agg/         <-- Python scripts folder
│   ├── __init__.py
│   ├── agg_agent.py
│   ├── metrics_node.py
│   ├── multi_visualizer.py
│   ├── sigma_node.py
├── launch_folder/
│   └── vis_launch.py  <-- launching file
├── resource/
│   └── dist_agg      <-- empty file
│   └── rviz_config.rviz
├── LICENSE.txt
├── package.xml
├── setup.cfg
├── setup.py

## Requirements:
- XLaunch for Windows

## Run Instructions:
1. Place the package in the `src` directory, which is inside the `docker_ws`.

2. Open the Docker terminal, or any other terminal like Windows PowerShell or Git Bash and go to the root directory containing `/docker_setup` and `/docker_ws`.

3. Start the container created beforehand if it is not started yet:
   ```bash
   docker start <container_name>

4. Execute the container:
docker exec -it <container_name> /bin/bash

5. If using Windows open and launch the XLaunch app 

6. Activate ROS2:
. /opt/ros/humble/setup.bash

7. Run this command to build the package:
rm -rf build/dist_agg install/dist_agg log
colcon build --packages-select dist_agg --symlink-install
. install/setup.bash

8. Launch the visualization file:
ros2 launch dist_agg vis_launch.py

9. The last command creates a csv file with metrics after the process is finished. To plot the metrics, exit from the execution mode, go inside the src directory and run the Python file:
exit
cd src
python plot_metrics.py