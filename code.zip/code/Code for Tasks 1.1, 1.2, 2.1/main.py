"""Main script to run experiments for Tasks 1.1, 1.2, and 2.1."""

import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from common_utils import mh_weights_from_graph, er_connected
from gt_consensus import run_gt_consensus
from consensus_cost import sample_instance, quad_cost
from plot_utils import plot_cost_and_gradnorm  
from localization_cost import unpack
from gt_localization import make_localization_data, run_gt_localization
from targloc_simulation_utils import plot_localization_snapshot
from agg_tracking import run_agg_tracking
from agg_animation_utils import animate_team

tol = 1e-6  # termination condition

########## Task 1.1 ############
def run_dist_cons(NN=10, dd=4, max_iters=2000, alpha=0.05, seed=1):
    Q_list, r_list, z_star = sample_instance(NN, dd, seed)
    #ell_star, _ = quad_cost(z_star, Q_list, r_list) # used for plotting

    # Different graph topologies
    graphs = {
        "path": nx.path_graph(NN),
        "cycle": nx.cycle_graph(NN),
        "star": nx.star_graph(NN - 1),
        "er": er_connected(NN, pp=0.35, seed=seed),
    }

    results = {}

    # Metrics calculation
    for name, G in graphs.items():
        A = mh_weights_from_graph(G)
        _, cost_vals, grad_vals =  run_gt_consensus(Q_list, r_list, A, max_iters=max_iters, alpha=alpha, seed=seed, tol=tol)
        results[name] = (cost_vals, grad_vals)

    # Metrics plotting
    plot_cost_and_gradnorm(results, max_iters)


########## Task 1.2 ############
def run_target_loc(NN=10, NN_T=3, dd=2, field=10.0, noise_std=0.02, max_iters=3000, alpha=1e-4, seed=2):
    PP, z_true, DD = make_localization_data(NN=NN, NN_T=NN_T, dd=dd, seed=seed, noise_std=noise_std, field=field)
    
    graphs = {
        # Can be tested with other graphs as well
        #"path": nx.path_graph(NN),
        #"cycle": nx.cycle_graph(NN),
        #"star": nx.star_graph(NN - 1),
        "er": er_connected(NN, pp=0.35, seed=seed),
    }

    results = {}

    # Metrics calculation
    for name, G in graphs.items():
        A = mh_weights_from_graph(G)
        _, cost_vals, grad_vals = run_gt_localization(PP, DD, NN_T, dd, A, max_iters=max_iters, alpha=alpha, seed=seed, tol=tol)
        results[name] = (cost_vals, grad_vals)

    # Metrics plotting
    plot_cost_and_gradnorm(results, max_iters)

    # Visualization of the last estimate
    G = graphs["er"]
    A = mh_weights_from_graph(G)
    z_traj, _, _ = run_gt_localization(PP, DD, NN_T, dd, A, max_iters=max_iters, alpha=alpha, seed=seed, tol=tol)
    zbar_last = z_traj[-1].mean(axis=0)
    z_blocks = unpack(zbar_last, NN_T, dd)
    est = np.array(z_blocks)
    plot_localization_snapshot(PP, z_true, DD, est, NN, NN_T)


########## Task 2.1 ##########
def run_agg_track(NN=12, max_iters=3000, alpha=0.05, aa=1.0, bb=1.0, field=10.0, seed=3, ANIMATE=False):
    rng = np.random.default_rng(seed)

    # Initial positions and private targets in a square [0, field]^2
    zz0 = rng.uniform(0.0, field, size=(NN, 2))
    G_targets = rng.uniform(0.0, field, size=(NN, 2))

    graphs = {
        #"path": nx.path_graph(NN),
        #"cycle": nx.cycle_graph(NN),
        #"star": nx.star_graph(NN - 1),
        "er": er_connected(NN, pp=0.35, seed=seed),
    }

    results = {}
    
    # Metrics calculation
    for name, G in graphs.items():
        A = mh_weights_from_graph(G)
        _, cost_vals, grad_vals = run_agg_tracking(A, G_targets, zz0, max_iters=max_iters, alpha=alpha, aa=aa, bb=bb, seed=seed, tol=tol)
        results[name] = (cost_vals, grad_vals)

    # Metrics plotting
    plot_cost_and_gradnorm(results, max_iters)

    # Animation
    if ANIMATE:
        G = graphs["er"]
        A = mh_weights_from_graph(G)
        z_traj, _, _, = run_agg_tracking(A, G_targets, zz0, max_iters=max_iters, alpha=alpha, aa=aa, bb=bb, seed=seed, tol=tol)
        fig, ax = plt.subplots(1, 1, figsize=(6, 6))
        animate_team(z_traj, G_targets, np.arange(max_iters), ax, wait=0.005, jump=10)
        #fig.savefig("figs/Task21_a2b1_animation.eps", format="eps", dpi=300, bbox_inches="tight")


if __name__ == "__main__":
    task = 3 # set to 1 for Task 1.1, 2 for Task 1.2, 3 for Task 2.1

    if task == 1:
        run_dist_cons(NN=10, dd=4, max_iters=2000, alpha=0.05, seed=1)
    elif task == 2:
        run_target_loc(NN=10, NN_T=10, dd=2, field=10.0, noise_std=0.02, max_iters=2000, alpha=1e-4, seed=2) # 10-5, 10-8, 10-10 # iter 2000
    elif task == 3:
        run_agg_track(NN=10, max_iters=2000, alpha=0.01, aa=1.0, bb=1.0, field=10.0, seed=3, ANIMATE=True)
    else:
        print("Invalid task flag. Use 1, 2 or 3.")