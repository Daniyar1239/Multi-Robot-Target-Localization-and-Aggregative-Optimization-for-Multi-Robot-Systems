"""Functions to generate cost functions and compute costs and gradients for the
localization optimization problem in Task 1.2."""

import numpy as np

# Splits a vector z into a list of N_T blocks (no. of targets) of size dd
def unpack(zz, NN_T, dd):
    return [zz[t * dd : (t + 1) * dd] for t in range(NN_T)]

# For each target i, computes the local cost and gradient and then returns the total cost and gradient over all targets
def local_cost_grad(zz, i, PP, DD, NN_T, dd):
    pp_i = PP[i]
    zz_blocks = unpack(zz, NN_T, dd)
    ell = 0.0
    gg = np.zeros_like(zz)
    for t in range(NN_T):
        e = np.linalg.norm(zz_blocks[t] - pp_i) ** 2 - DD[i, t] ** 2
        ell += e ** 2
        gg[t * dd : (t + 1) * dd] = 4.0 * e * (zz_blocks[t] - pp_i)
    return ell, gg

# Computes the total cost and gradient norm across all robots (not only targets)
def compute_cost_gradnorm(zbar, PP, DD, NN_T, dd):
    NN = PP.shape[0]
    cost = 0.0
    grad_sum = np.zeros_like(zbar)
    for i in range(NN):
        ell_i, gi = local_cost_grad(zbar, i, PP, DD, NN_T, dd)
        cost += ell_i
        grad_sum += gi
    return cost, np.linalg.norm(grad_sum)

