"""Implementation of the Gradient Tracking (GT) algorithm for solving the localization optimization
problem in a distributed manner in Task 1.2."""

import numpy as np
from localization_cost import local_cost_grad, compute_cost_gradnorm

def make_localization_data(NN=10, NN_T=3, dd=2, seed=2, noise_std=0.02, field=10.0):
    rng = np.random.default_rng(seed)

    # Fixed robot positions p_i 
    PP = rng.uniform(0.0, field, size=(NN, dd)) # between 0 and value of field

    # Ground-truth target positions zz_true
    zz_true = rng.uniform(0.0, field, size=(NN_T, dd))

    # Noisy measurements of target positions DD
    DD = np.zeros((NN, NN_T))
    for i in range(NN):
        for t in range(NN_T):
            r = np.linalg.norm(zz_true[t] - PP[i])  # true distance between robot i and target t
            DD[i, t] = max(0.0, r + rng.normal(scale=noise_std)) # adding gaussian noise and ensuring non-negativity

    return PP, zz_true, DD

def run_gt_localization(PP, DD, NN_T, dd, A, max_iters=3000, alpha=5e-3, seed=1, tol=1e-12):
    NN = PP.shape[0]
    rng = np.random.default_rng(seed)

    zz = np.zeros((max_iters, NN, dd * NN_T))
    ss = np.zeros((max_iters, NN, dd * NN_T))

    zz[0] = rng.uniform(low=0.0, high=np.max(PP), size=(NN, dd * NN_T))

    # Initial gradient computation
    for i in range(NN):
        _, ss[0, i] = local_cost_grad(zz[0, i], i, PP, DD, NN_T, dd)

    cost = np.zeros(max_iters)
    gradnorm = np.zeros(max_iters)

    for kk in range(max_iters - 1):
    
        # Update the estimate
        zz[kk + 1] = A @ zz[kk] - alpha * ss[kk]
        ssmix = A @ ss[kk]

        # Update the gradient tracking variable
        for i in range(NN):
            _, grad_new = local_cost_grad(zz[kk + 1, i], i, PP, DD, NN_T, dd)
            _, grad_old = local_cost_grad(zz[kk, i], i, PP, DD, NN_T, dd)
            ss[kk + 1, i] = ssmix[i] + (grad_new - grad_old)

        zbar = zz[kk].mean(axis=0)
        cost[kk], gradnorm[kk] = compute_cost_gradnorm(zbar, PP, DD, NN_T, dd) # compute global cost and gradient norm

        # Stopping condition
        if kk > 0 and gradnorm[kk] < tol:
            cost[kk+1:] = cost[kk]
            gradnorm[kk+1:] = gradnorm[kk]
            zz[kk+2:] = zz[kk+1]
            max_iters = kk  # if we want to trim the result
            break

    return zz[:max_iters-1], cost[:max_iters-1], gradnorm[:max_iters-1]