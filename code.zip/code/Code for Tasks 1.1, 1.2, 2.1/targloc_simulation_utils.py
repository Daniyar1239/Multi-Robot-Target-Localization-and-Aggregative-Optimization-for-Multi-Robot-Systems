"""Utility functions for plotting localization simulation snapshots."""

import matplotlib.pyplot as plt
import numpy as np

def plot_localization_snapshot(PP, z_true, DD, est, NN, NN_T, title="Localization plot (ER graph)"):
    
    fig, ax = plt.subplots(1, 1, figsize=(6, 6))
    ax.scatter(PP[:, 0], PP[:, 1], c="tab:blue", marker="s", label="robots p_i")  # robot positions
    ax.scatter(z_true[:, 0], z_true[:, 1], c="tab:green", marker="*", s=180, label="targets true") # true target positions
    ax.scatter(est[:, 0], est[:, 1], c="tab:red", marker="o", label="targets est.") # estimated target positions
    for i in range(NN):
        for t in range(NN_T):
            circ = plt.Circle(PP[i], DD[i, t], color="grey", fill=False, alpha=0.15) # a circle centered at pp_i with radius dd_it
            ax.add_patch(circ)
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.legend()
    ax.grid(True, linestyle=":", alpha=0.5)
    plt.show()

    #fig.savefig("figs/Task12_N1010_nonoise_snapshot.eps", format="eps", dpi=300, bbox_inches="tight")