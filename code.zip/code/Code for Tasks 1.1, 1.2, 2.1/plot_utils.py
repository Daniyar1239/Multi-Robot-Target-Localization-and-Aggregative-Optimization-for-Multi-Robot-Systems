"""Utility functions for plotting cost and gradient norm values."""

import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({'font.size': 14})

def plot_cost_and_gradnorm(results, max_iters=2000):
    
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    ax_cost, ax_gradnorm = axes
    #kk = np.arange(max_iters)

    for name, (cost_vals, grad_vals) in results.items():
        kk = np.arange(len(cost_vals))
        ax_cost.semilogy(kk, cost_vals, label=name)
        ax_gradnorm.semilogy(kk, grad_vals, label=name)

    ax_cost.set_xlabel("iteration k")
    ax_cost.set_ylabel(r"$\ell(z^k)$")
    ax_cost.grid(True, which="major", linestyle=":", linewidth=0.8)
    ax_cost.legend(title="graph", loc="upper right")

    ax_gradnorm.set_xlabel("iteration k")
    ax_gradnorm.set_ylabel(r"$\|\nabla \ell(z^k)\|_2$")
    ax_gradnorm.grid(True, which="major", linestyle=":", linewidth=0.8)
    ax_gradnorm.legend(title="graph", loc="upper right")

    plt.tight_layout()
    plt.show()

    #fig.savefig("figs/Task21_a2b1_cost_gradnorm.eps", format="eps", dpi=300, bbox_inches="tight")
