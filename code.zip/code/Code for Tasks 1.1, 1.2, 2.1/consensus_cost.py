"""Functions to generate quadratic cost functions for the consensus optimization
problem in Task 1.1."""

import numpy as np

# Generating matrices Q and vectors r
def sample_instance(NN, dd, seed=0):
    rng = np.random.default_rng(seed)
    # uniform distribution where the smallest value is 0.2 and the largest is 1.0 
    QQ_list = [np.diag(rng.uniform(low=0.2, high=1.0, size=dd)) for _ in range(NN)] # d x d psd matrices for N robots
    rr_list = [rng.normal(size=dd) for _ in range(NN)] # normal distribution
    QQ_tot = sum(QQ_list)
    rr_tot = sum(rr_list)
    z_star = -np.linalg.solve(QQ_tot, rr_tot) # optimal solution accross N robots
    return QQ_list, rr_list, z_star

# Computing the cost and gradient norm at a given point zbar
def quad_cost(zbar, QQ_list, rr_list):
    cost = sum(0.5 * zbar.T @ QQ @ zbar + rr.T @ zbar for QQ, rr in zip(QQ_list, rr_list))
    gradnorm = np.linalg.norm(sum(QQ @ zbar + rr for QQ, rr in zip(QQ_list, rr_list)))
    return cost, gradnorm