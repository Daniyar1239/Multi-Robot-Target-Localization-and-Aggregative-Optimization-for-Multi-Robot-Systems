"""Common utility functions for graph generation and weighted adjacency matrix computation 
using MH weighting method."""

import numpy as np
import networkx as nx

# Metropolis-Hastings (MH) weights (a method to ensure that A is doubly stochastic)
def mh_weights_from_graph(G):
    NN = G.number_of_nodes()
    A = np.zeros((NN, NN), dtype=float)
    deg = dict(G.degree())
    for i in range(NN):
        for j in G.neighbors(i):
            if i != j:
                A[i, j] = 1.0 / (1.0 + max(deg[i], deg[j]))
        A[i, i] = 1.0 - np.sum(A[i, :])
    return A

# ER graph
def er_connected(NN, pp=0.3, seed=1):
    rng = np.random.default_rng(seed)
    while True:
        G = nx.erdos_renyi_graph(NN, p=pp, seed=seed)
        if nx.is_connected(G):
            return G