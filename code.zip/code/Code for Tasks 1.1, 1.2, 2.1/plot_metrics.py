import pandas as pd
from plot_utils import plot_cost_and_gradnorm 

def plot_metrics_from_csv(csv_path: str, label: str = "run"):
    df = pd.read_csv(csv_path)

    cost_vals = df["cost"].to_numpy()
    grad_vals = df["grad_norm"].to_numpy()
    max_iters = len(df)

    results = {label: (cost_vals, grad_vals)}
    plot_cost_and_gradnorm(results, max_iters)

if __name__ == "__main__":
    plot_metrics_from_csv("metrics.csv", label="star") 
