"""Utility functions for animating multi-robot trajectories 
for the aggregation and tracking problem of Task 2.1."""

import numpy as np
import matplotlib.pyplot as plt

def animate_team(ZZ, targets, horizon, ax, wait=0.03, jump=10):
   
    TT, _ , _ = ZZ.shape # TxNx2(d) dim
    xlim = (np.min(ZZ[:, :, 0]) - 1, np.max(ZZ[:, :, 0]) + 1)
    ylim = (np.min(ZZ[:, :, 1]) - 1, np.max(ZZ[:, :, 1]) + 1)

    def draw_frame(tt, show_legend=False):
        ax.cla()
        
        # Trajectories (where each robot came from)
        ax.plot(ZZ[:tt + 1, :, 0], ZZ[:tt + 1, :, 1], linestyle=":", alpha=0.4)
        
        # Current robot positions
        ax.scatter(ZZ[tt, :, 0], ZZ[tt, :, 1], c="tab:blue", label="robots")
        
        # Target positions
        ax.scatter(targets[:, 0], targets[:, 1], c="tab:orange", marker="*", s=120, label="targets")
        
        # Barycenter (in our case it is the mean of all robot positions)
        sigma = ZZ[tt].mean(axis=0)
        ax.scatter([sigma[0]], [sigma[1]], c="tab:red", marker="x", s=80, label="barycenter")

        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        ax.set_aspect("equal")
        ax.set_title(f"Iteration {horizon[tt]}")
        ax.grid(True, linestyle=":", alpha=0.4)
        
        if show_legend:
            ax.legend(loc="upper right")

    frames = list(range(0, TT, jump))
    if frames[-1] != TT - 1:
        frames.append(TT - 1)

    for idx, t in enumerate(frames):
        draw_frame(t, show_legend=(idx == 0))
        plt.show(block=False)
        plt.pause(wait)

    final_tt = frames[-1]
    draw_frame(final_tt, show_legend=True)
   
    plt.ioff()
    plt.show()

