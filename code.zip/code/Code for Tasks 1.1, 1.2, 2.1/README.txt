Multi-Robot Target Localization & Aggregative Optimization for Multi-Robot Systems

Description:
------------
This project uses the Gradient Tracking (GT) and Aggregative Tracking (AT) algorithms to solve the distributed consensus and aggregative optimization problems for practical applications in multi-robot environments. The project provides the code for running those algorithms, plotting the metrics, and visualizing the robots' behavior.

Project Structure:
------------------
1. main.py
   - Main script to run the code for Tasks 1.1, 1.2, and 2.1 of the project

2. gt_consensus.py

3. consensus_cost.py

4. common_utils.py

5. gt_localization.py

6. localization_cost.py

7. targloc_simulation_utils.py

8. agg_tracking.py

9. agg_cost.py

10. agg_animation_utils.py

11. plot_utils.py

Requirements:
-------------
- Python 3.8+
- NumPy
- Networkx
- Matplotlib

Run Instructions:
-----------------
1. Set the desired flag for a task: 1 for Task 1.1, 2 for Task 1.2, and 3 for Task 2.1 in the main.py file
2. Open the terminal and provide the path to the project folder 
4. Run the project: python main.py
