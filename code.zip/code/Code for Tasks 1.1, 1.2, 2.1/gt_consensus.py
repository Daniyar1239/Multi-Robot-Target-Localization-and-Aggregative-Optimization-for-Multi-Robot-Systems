"""Implementation of the Gradient Tracking (GT) algorithm for solving the consensus optimization
problem in a distributed manner in Task 1.1."""

import numpy as np
from consensus_cost import quad_cost

def run_gt_consensus(QQ_list, rr_list, A, max_iters=2000, alpha=0.05, seed=1, tol=1e-12):
    NN = len(QQ_list)
    dd = QQ_list[0].shape[0]
    rng = np.random.default_rng(seed)

    zz = np.zeros((max_iters, NN, dd))
    ss = np.zeros((max_iters, NN, dd))

    zz[0] = rng.normal(scale=0.5, size=(NN, dd)) # mean = 0, std = 0.5 (normal distribution)

    for i in range(NN):
        ss[0, i] = QQ_list[i] @ zz[0, i] + rr_list[i]  # gradient at z[0, i] for each robot
    
    cost = np.zeros(max_iters)
    gradnorm = np.zeros(max_iters)

    for kk in range(max_iters-1):
        
        # Update the estimate
        zz[kk+1] = A @ zz[kk] - alpha * ss[kk]
        ssmix = A @ ss[kk]

        # Update the gradient tracking variable
        for i in range(NN):
            grad_new = QQ_list[i] @ zz[kk+1, i] + rr_list[i]
            grad_old = QQ_list[i] @ zz[kk, i] + rr_list[i]
            ss[kk+1, i] = ssmix[i] + (grad_new - grad_old)
        
        zbar = zz[kk].mean(axis=0)  
        cost[kk], gradnorm[kk] = quad_cost(zbar, QQ_list, rr_list) # compute global cost and gradient norm

        # Stopping condition
        if kk > 0 and gradnorm[kk] < tol:
            cost[kk+1:] = cost[kk]
            gradnorm[kk+1:] = gradnorm[kk]
            zz[kk+2:] = zz[kk+1]
            max_iters = kk  # if we want to trim the result
            break
    
    return zz[:max_iters-1], cost[:max_iters-1], gradnorm[:max_iters-1]