"""Functions to compute local costs and gradients, as well as global metrics 
for the aggregation and tracking problem of Task 2.1."""

import numpy as np

def local_cost_and_grad(zz_i, sigma, pp_i, aa=1.0, bb=1.0):
    
    diff_t = zz_i - pp_i  # distance of a robot to its private target
    diff_c = zz_i - sigma  # distance of a robot to the barycenter (comm. constraint)
    ell_i = 0.5 * aa * (diff_t @ diff_t) + 0.5 * bb * (diff_c @ diff_c) # local cost
    grad_i = aa * diff_t + bb * diff_c # local gradient
    return ell_i, grad_i


def compute_global_metrics(zbar, aa, bb, G):
   
    NN = zbar.shape[0]
    sigma = np.mean(zbar, axis=0)
    cost = 0.0
    grad_sum = np.zeros(2)
    for i in range(NN):
        ell_i, grad_i = local_cost_and_grad(zbar[i], sigma, G[i], aa=aa, bb=bb)
        cost += ell_i # total (global) cost
        grad_sum += grad_i + (1 / NN) * np.sum(bb * (zbar[i] - sigma), axis=0) # total (global) gradient
    return cost, np.linalg.norm(grad_sum)
