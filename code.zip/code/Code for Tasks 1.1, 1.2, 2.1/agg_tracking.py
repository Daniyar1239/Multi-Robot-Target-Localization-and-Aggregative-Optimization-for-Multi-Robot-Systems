"""Implementation of the aggregative tracking (AT) algorithm for solving the
aggregative optimization problem in a distributed manner in Task 2.1."""

import numpy as np
from agg_cost import local_cost_and_grad, compute_global_metrics

def run_agg_tracking(A, G_targets, zz0, max_iters=2000, alpha=0.05, aa=1.0, bb=1.0, seed=3, tol=1e-12):
   
    NN = A.shape[0]

    zz = np.zeros((max_iters, NN, 2))
    yy = np.zeros((max_iters, NN, 2)) # we store local grads here
    ss = np.zeros((max_iters, NN, 2))  

    zz[0] = zz0.copy()
    ss[0] = zz0.copy() 

    cost = np.zeros(max_iters)
    gradnorm = np.zeros(max_iters)

    for kk in range(max_iters - 1):
        # Compute local gradients using current sigma estimates
        for i in range(NN):
            _, g_i = local_cost_and_grad(zz[kk, i], ss[kk, i], G_targets[i], aa=aa, bb=bb)
            yy[kk, i] = g_i

        # Local descent step 
        zz[kk + 1] = zz[kk] - alpha * yy[kk]

        # Dynamic average tracking of sigma = mean(z)
        ss[kk + 1] = A @ ss[kk] + (zz[kk + 1] - zz[kk])

        ## vv variable is zero
        
        # Metrics 
        cost[kk], gradnorm[kk] = compute_global_metrics(zz[kk], aa=aa, bb=bb, G=G_targets)

        # Stopping condition
        if kk > 0 and (gradnorm[kk] < tol or np.abs(cost[kk] - cost[0]) < tol):
            cost[kk+1:] = cost[kk]
            gradnorm[kk+1:] = gradnorm[kk]
            zz[kk+2:] = zz[kk+1]
            max_iters = kk  # if we want to trim the result
            break

    return zz[:max_iters-1], cost[:max_iters-1], gradnorm[:max_iters-1]
